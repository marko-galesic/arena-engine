#include "Clock.hpp"
// Clock implementation - currently header-only, but keeping for future extensions
