#include "arena/ecs/registry.hpp"

namespace arena::ecs {
// All implementation is now in the header file as templates
} // namespace arena::ecs
