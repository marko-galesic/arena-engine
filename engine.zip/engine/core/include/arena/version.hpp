#pragma once
namespace arena { struct Version { static int major(){return 0;} }; }
